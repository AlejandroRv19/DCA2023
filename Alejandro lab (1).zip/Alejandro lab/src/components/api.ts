export interface uno {name:string;height:string;mass:string} 

export const getCharacters = async(): Promise<Array<uno>> => {
    const response = await fetch("https://swapi.dev/api/people/");
    const data = await response.json();
    console.log(data.results);
    return data.results;
}