import {getCharacters} from "../api"
import {uno} from "../api"

export default class unos extends HTMLElement {

    constructor() {
        super();
        this.attachShadow({mode: 'open'})
    }

    async connectedCallback(){
        const dos = await getCharacters(); 
        this.render(dos);
        }

        render(dos: Array<uno>){

            //console.log(Hola)
        
            if(!this.shadowRoot) return; {
                const hola = dos.map(({name,height,mass}) => `
            
            <h2>${name}</h2>
            
            <h2>${mass}</h2>

            <h2>${height}</h2>
            
            `);

            this.shadowRoot.innerHTML = ` ${hola.join("")}`;
            
            }

        }


    }

customElements.define('comp-uno', unos);