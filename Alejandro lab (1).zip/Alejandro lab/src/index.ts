import "./components/card/1"

class App extends HTMLElement { 

    constructor() {
        super();
        this.attachShadow({mode: 'open'})
    }

    connectedCallback(){
        this.render();
        }
        render(){
        
            if(this.shadowRoot){
                this.shadowRoot.innerHTML = ` 
                
                hola
                <comp-uno> </comp-uno>`;
            }
        }
    }

customElements.define('comp-app', App);