import { getData } from "../api/getData";
import { ApiType } from "../types/Apitype";
import { AttributeCard } from "../components/Cardjoke/Card";
import "../components/export"

class Dashboard extends HTMLElement{
    constructor(){
        super();
        this.attachShadow({mode: 'open'});
    }

    async connectedCallback(){
        const data = await getData();
        this.render(data);
    }

    render(data: any){  
        if(this.shadowRoot) this.shadowRoot.innerHTML = `
        
        
        `;

        data.forEach((e:ApiType) => {
            const card = this.ownerDocument.createElement('app-card');

            card.setAttribute(AttributeCard.value, e.value)
            this.shadowRoot?.appendChild(card);
        })
    }
}

customElements.define('app-dashboard', Dashboard);