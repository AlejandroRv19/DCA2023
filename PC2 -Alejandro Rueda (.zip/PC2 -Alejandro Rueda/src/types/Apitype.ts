export interface ApiType {
    value : string,
   
}