import { Tarjeta } from "./tarjeta1";

class tarjeta1 extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'})
    }

    connectedCallback(){
        this.render();
        
    }

    render(){
        this.shadowRoot.innerHTML = `
        <p></p>`;
    }

}

customElements.define('comp-tarejta', Tarjeta);