export {default as tarjeta1} from './Tarjeta/tarjeta1.js';
export { PlanesTuristicos } from './data/data.js';
export { Tarjeta1} from './Tarjeta/tarjeta1.js';
export { data } from './data/data.js';
export { Tarjeta2} from './Tarjeta/tarjeta1.js';