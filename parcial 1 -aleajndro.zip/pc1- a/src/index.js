import "./components/index.js"
import "./components/data/data"

class App extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({mode: 'open'})
    }

    connectedCallback() {
        this.render()
    }

    render() {
        this.shadowRoot.innerHTML = `
        <comp-tarjeta>
        
        
        <div>     Planes turisticos </div>
        <div>     Destino </div>
        <div>     costo </div>
        <div>     descripcion </div>
        div>     actvidades </div>
        
        </comp-tarjeta>`;
    }

}

customElements.define('comp-app', App);